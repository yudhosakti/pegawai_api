const host = "http://192.168.1.2:4000/"

module.exports  = {
    host
}